
clear all;
clc;

load ('openloop.mat');
plot(ans_openloop(1,:),ans_openloop(2,:),'b-','Linewidth', 2);
title('Open loop step response diagram');
xlabel('Time, Sec');
ylabel('Megnitude');
grid on;
hold on;


load ('step_fi.mat');
plot(ans_step_fi(1,:),ans_step_fi(2,:),'r-.','Linewidth', 2);
grid on;
hold on;