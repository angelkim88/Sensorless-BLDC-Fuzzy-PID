%cohen-coon
clear all;
clc;

G = tf([1.3775],[0.1767*10^-6 0.00473 1])

figure;
step(G, 0.05,'r-.' ); % 0.05������
title('open loop step response diagram');
xlabel('time, sec');
ylabel('voltage, volt');
grid on;
hold on;

load ('openloop.mat');
plot(ans_openloop(1,:),ans_openloop(2,:));
hold on;

load ('diff.mat');
plot(ans_diff(1,:),ans_diff(2,:));
hold on;
% 0.000204415441816398  ,  0.0481004437050777
% [0.000192391362350066,0.000204415441816398;0.0447077649498715,0.0481004437050777]



a = (0.0481004437050777 - 0.0447077649498715) / (0.000204415441816398 - 0.000192391362350066);
b = 0.0481004437050777 - (a*0.000204415441816398);
x = ans_openloop(1,:);

y=(a*x)+b;
plot(ans_openloop(1,:),y);

y_0 = -b/a % y�� 0�϶� 
y_1 = (1.3775-b)/a % y�� 1�� ��

T = y_1 - y_0 
L = y_0

%P = 0.9*(T/L)
%I = L/0.3

P=1.2*(T/L)
I=2*L
D=0.5*L


load ('Z_N_PID.mat');
plot(ans_Z_N_PID(1,:),ans_Z_N_PID(2,:));
hold on;

