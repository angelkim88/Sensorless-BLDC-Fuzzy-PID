



%% Open Loop %%
%load ('openloop.mat');
%plot(ans_openloop(1,:),ans_openloop(2,:),'b-','Linewidth', 2);
%title('Response diagram');
%xlabel('Time, Sec');
%ylabel('Megnitude');
%grid on;
%hold on;


%% Step Function Response %%
load ('step_fi.mat');
plot(ans_step_fi(1,:),ans_step_fi(2,:),'g--','Linewidth', 2);
xlabel('Time, Sec');
ylabel('Megnitude');
grid on;
hold on;


%% Ziegler Nichols PID %%
load ('Z_N_PID.mat');
plot(ans_Z_N_PID(1,:),ans_Z_N_PID(2,:),'r-.','Linewidth', 2);
hold on;


%% Fuzzy Controller %%
load ('Fuzzy_final.mat');
plot(ans_Fuzzy_final(1,:),ans_Fuzzy_final(2,:),'b-.','Linewidth', 2);
hold on;


%% Self Tuning Fuzzy Controller %%
load ('Auto_Fuzzy_final.mat');
plot(ans_Auto_Fuzzy_final(1,:),ans_Auto_Fuzzy_final(2,:),'m:','Linewidth', 2);
hold on;



%% Self Tuning Fuzzy - PID Controller %%
load ('Auto_Fuzzy_PID.mat');
plot(ans_Auto_Fuzzy_PID(1,:),ans_Auto_Fuzzy_PID(2,:),'k','Linewidth', 2);
hold on;








